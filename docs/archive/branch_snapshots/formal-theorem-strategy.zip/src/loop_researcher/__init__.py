"""Autonomous loop researcher scaffold."""
